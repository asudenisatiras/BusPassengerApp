//
//  TicketViewController.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 6.04.2023.
//

import UIKit

class TicketViewController: UIViewController {
    
    var buyedBus : BusCompany?
    var buyedPlace : [String] = []
    var buyPrice : Int = 0
    var id = 0
    var usersName = ""
    var usersSurname = ""
    var identityy =  ""
    var perSeatPrice = ""
    var selectedSeatNo = ""
    var selectedseats = ""
    var identitytexting = "" 
    let alert = UIAlertController(title: "Ödeme Alınamadı", message: "Lütfen Geçerli Bir Kart Giriniz!", preferredStyle: UIAlertController.Style.alert)
    
    @IBOutlet weak var identityTextField: UITextField!
    
    @IBOutlet weak var nameSurnameTextField: UITextField!
    
    @IBOutlet weak var surnameTextField: UITextField!
    
    @IBOutlet weak var reservedSeats: UITextField!
    
    
    @IBOutlet weak var creditcardNo: UITextField!
    
    
    @IBOutlet weak var exprationDateTextField: UITextField!
    
    
    @IBOutlet weak var cvcTextField: UITextField!
    
    @IBOutlet weak var totalPricedTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let stringRepresentation = buyedPlace.joined(separator: ",")
        alert.addAction(UIAlertAction(title: "Okey",style:UIAlertAction.Style.default,handler: nil))
        reservedSeats.text = stringRepresentation
        totalPricedTextField.text = perSeatPrice
        reservedSeats.text = selectedSeatNo
        
    }
    @IBAction func paymentButton(_ sender: Any) {
        usersName = nameSurnameTextField.text!
        selectedseats = reservedSeats.text!
        
        if nameSurnameTextField.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "Please enter your name!", defaultTitle: "OK", viewController:self)
            
        }
        if surnameTextField.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "Please enter your surname!", defaultTitle: "OK", viewController:self)
            
        }
        if cvcTextField.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "Please enter CVC!", defaultTitle: "OK", viewController:self)
            
        }
        if identityTextField.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "Please enter your identity!", defaultTitle: "OK", viewController:self)
           
        }
        if creditcardNo.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "Please enter your Card Number!", defaultTitle: "OK", viewController:self)
            
        }
        if exprationDateTextField.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "Please enter Expration Date!", defaultTitle: "OK", viewController:self)
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "lastVC" {
            let lastDestinationVC = segue.destination as! TicketPrintViewController
            lastDestinationVC.nameTexting = nameSurnameTextField.text!
            lastDestinationVC.surnameTexting = surnameTextField.text!
            lastDestinationVC.identitytexting = identityTextField.text!
            lastDestinationVC.selectedseats = reservedSeats.text!
        }
        
    }
    
}
           
                
                
            
            
          
            
