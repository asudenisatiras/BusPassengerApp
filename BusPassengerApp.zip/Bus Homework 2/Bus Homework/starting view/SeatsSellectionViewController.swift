//
//  SeatsSellectionViewController.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 5.04.2023.
//

import UIKit

class SeatsSellectionViewController: UIViewController {
    
    var bus: BusCompany?
    var totalPrice = 0
    var selectedBus : BusCompany?
    var count = 0
    var selectedIndexPath: IndexPath?
    var selectedSeats = [Int]()
    var pathWayNumber = Int()
    var seatNumber = Int()
    var totalSeats = 50
    var reserved = [Int]()
    var companysname = ""
    var companysImage = ""
    var perSeatPrice = ""
    var selectedSeatNo = ""
    let seatPrice = 350
    
    @IBOutlet weak var seatsCollectionView: UICollectionView!
    
    @IBOutlet weak var selectingSeatLabel: UILabel!
    
    @IBOutlet weak var SelectedSeatLabel: UILabel!
    
    @IBOutlet weak var totalPricingLabel: UILabel!
    
    @IBOutlet weak var totalPricedLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureCollectionView()
        seatsCollectionView?.reloadData()
        
    }
    
    private func configureCollectionView(){
        
        seatsCollectionView.delegate = self
        seatsCollectionView.dataSource = self
        
    }
    
    @IBAction func goToPayment(_ sender: Any) {
       perSeatPrice = totalPricedLabel.text!
       selectedSeatNo = SelectedSeatLabel.text!
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
            if segue.identifier == "ticketing" {
                let ticketingDestinationVC = segue.destination as! TicketViewController
                ticketingDestinationVC.perSeatPrice = totalPricedLabel.text!
                ticketingDestinationVC.selectedSeatNo = SelectedSeatLabel.text!
                
            }
    }
    
    @IBAction func findTicketButton(_ sender: UIButton) {
        if selectedSeats.count == 0 {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "No Seat Selection", defaultTitle: "OK",  viewController:self)
        }
    }
    
    
}
extension SeatsSellectionViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView( _ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 55
        
    }

    func collectionView( _ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
     let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "seatCell", for: indexPath) as! SeatsCollectionViewCell
     
     let hidden = (indexPath.row - 2) % 5 == 0 && indexPath.row <= totalSeats
        
        cell.isHidden = hidden

        cell.configure(model: SeatsModel(seatImage: "smChair", seatNumber: indexPath.row + 1))
        
        if selectedSeats.contains(indexPath.row+1) {
            cell.backgroundColor = UIColor.systemBlue
               } else {
                   cell.backgroundColor = UIColor.clear
               }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedCell = collectionView.cellForItem(at: indexPath) as! SeatsCollectionViewCell
        let seatNumber = indexPath.row + 1
            if selectedSeats.contains(seatNumber) {
                if let index = selectedSeats.firstIndex(of: seatNumber) {
                        selectedSeats.remove(at: index)
                    }
                    selectedCell.backgroundColor = UIColor.clear
                } else {
                    if selectedSeats.count < 5 {
                        selectedSeats.append(seatNumber)
                        selectedCell.backgroundColor = UIColor.systemBlue
                       }
                    if selectedSeats.count >=  5 {
                        Alert.showAlert(alertTitle: "Warning!", alertMessage: "No more than 5 seats can be selected!", defaultTitle: "OK", viewController:self)
                    }
                             }
        reserved = selectedSeats.sorted()
        SelectedSeatLabel.text = "\(reserved.map { String($0) }.joined(separator: ", " ))"
        let totalPrice = reserved.count * seatPrice
        totalPricedLabel.text = " \(totalPrice) TL"
        print("Selected seats: \(reserved)")
    }

    }

    



    
    
        
        
    
   
        
        
        
    


    
   
        
      
    

