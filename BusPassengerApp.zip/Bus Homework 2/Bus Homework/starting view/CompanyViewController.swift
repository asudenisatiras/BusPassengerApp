//
//  companyViewController.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 4.04.2023.
//

import UIKit

class CompanyViewController: UIViewController {
    //Variables
    var fromCityName = ""
    var toCityName = ""
    var busCompany = [BusCompany]()
    var bus: BusCompany?
    var date: String = ""
    var time: String!
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Protocols
        tableView.delegate = self
        tableView.dataSource = self
        
        //Identifier
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        
        //Table View Cell Items Adding
        busCompany.append(BusCompany(busImage: "benturizm", time: "09.00", price: "500TL",seatOptions: "2+2", companyName: "Ben Turizm"))
        busCompany.append(BusCompany(busImage: "kamilkoc", time: "11.00", price: "500TL",seatOptions: "2+2", companyName: "Kamil Koç"))
        busCompany.append(BusCompany(busImage: "metro", time: "9.30", price: "500TL",seatOptions: "2+2", companyName: "Metro Turizm"))
        busCompany.append(BusCompany(busImage: "ulusoy", time: "12.00", price: "500TL",seatOptions: "2+2",companyName: "Ulusoy Turizm"))
        busCompany.append(BusCompany(busImage: "benturizm", time: "13.00", price: "500TL",seatOptions: "2+2", companyName: "Ben Turizm"))
        busCompany.append(BusCompany(busImage: "metro", time: "19.00", price: "500TL",seatOptions: "2+2", companyName: "Metro Turizm"))
        busCompany.append(BusCompany(busImage: "kamilkoc", time: "00.00", price: "500TL",seatOptions: "2+2", companyName: "Kamil Koç"))
        busCompany.append(BusCompany(busImage: "ulusoy", time: "01.00", price: "500TL",seatOptions: "2+2", companyName: "Ulusoy Turizm"))
        busCompany.append(BusCompany(busImage: "benturizm", time: "03.00", price: "500TL",seatOptions: "2+2", companyName: "Ben Turizm"))
        
        
        tableView.separatorStyle = .singleLine
        tableView.separatorColor = UIColor.systemBlue
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        
        //Console Writing(for check)
       print(date)
       print(fromCityName)
       print(toCityName)
    }
}

 extension CompanyViewController: UITableViewDelegate, UITableViewDataSource {
     
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        busCompany.count
     }
     
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.configure(model: busCompany[indexPath.row])
        cell.fromCityLabel.text = fromCityName
        cell.toCityLabel.text = toCityName
        cell.dateLabel.text =  date 
        return cell
    }
     
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            bus = busCompany[indexPath.row]
            performSegue(withIdentifier: "toSeatsSelection", sender: nil)
            tableView.deselectRow(at: indexPath, animated: true)
        
            time = busCompany[indexPath.row].time
            UserDefaults.standard.set(time, forKey: "time")
        }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "toSeatsSelection" {
             let destinationDetailVc = segue.destination as! SeatsSellectionViewController
                destinationDetailVc.bus = bus
            }
        }
    }
     
