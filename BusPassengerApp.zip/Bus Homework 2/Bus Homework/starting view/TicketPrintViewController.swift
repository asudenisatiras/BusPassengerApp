//
//  TicketPrintViewController.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 9.04.2023.
//

import UIKit

class TicketPrintViewController: UIViewController {
    
    var nameTexting = ""
    var identitytexting = ""
    var surnameTexting = ""
    var selectedseats = ""
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var voyageLabel: UILabel!
    
    @IBOutlet weak var seatsNoLabel: UILabel!
    @IBOutlet weak var identityLabel: UILabel!
    @IBOutlet weak var surnameLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = UserDefaults.standard.object(forKey: "traveldate")
        if let usePicker = defaults as? String  {
            
            dateLabel.text = "\(usePicker)"
        }
        let defaults1 = UserDefaults.standard.object(forKey: "time")
        if let timeLabels = defaults1 as? String  {
            
            voyageLabel.text = "\(timeLabels)"
        }
        nameLabel.text = nameTexting
        identityLabel.text = identitytexting
        surnameLabel.text = surnameTexting
        seatsNoLabel.text = selectedseats
    }
    @IBAction func returnHomeButton(_ sender: Any) {
        
       
    }
    
}
