//
//  SeatsModel.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 5.04.2023.
//

import Foundation
import UIKit

struct SeatsModel {
    var seatImage: String
    var seatNumber: Int
}
