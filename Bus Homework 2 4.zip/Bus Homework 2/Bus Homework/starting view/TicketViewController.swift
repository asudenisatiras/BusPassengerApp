//
//  TicketViewController.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 6.04.2023.
//

import UIKit

class TicketViewController: UIViewController {
 
    var buyedBus : BusCompany?
    var buyedPlace : [String] = []
    var buyPrice : Int = 0
    var id = 0
    
    
    let alert = UIAlertController(title: "Ödeme Alınamadı", message: "Lütfen Geçerli Bir Kart Giriniz!", preferredStyle: UIAlertController.Style.alert)
    
    @IBOutlet weak var identityTextField: UITextField!
    
    
    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    
    @IBOutlet weak var mailTextField: UITextField!
    
    @IBOutlet weak var nameSurnameTextField: UITextField!
    
    
    @IBOutlet weak var reservedSeats: UITextField!
    
    
    @IBOutlet weak var creditcardNo: UITextField!
    
    
    @IBOutlet weak var exprationDateTextField: UITextField!
    
    
    @IBOutlet weak var cvcTextField: UITextField!
    
    @IBOutlet weak var totalPricedTextField: UITextField!
    
   // var nameSurname = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let stringRepresentation = buyedPlace.joined(separator: ",")
        alert.addAction(UIAlertAction(title: "Tamam",style:UIAlertAction.Style.default,handler: nil))
        reservedSeats.text = stringRepresentation
        totalPricedTextField.text = String(buyPrice)
       
        
        
    
            
         
       
    }
    

    @IBAction func paymentButton(_ sender: Any) {
        
//        if cardCheck(cvc: cvcTextField.text!, carNo: creditcardNo.text!, cardDate: exprationDateTextField.text!) == true {
//            getPassengerInfo(name: nameSurnameTextField.text ?? "empty", mail: mailTextField.text ?? "empty", tel: phoneNumberTextField.text ?? "empty")
//            
//            buyedBus?.buyPlace(places: buyedPlace)
    }
        
            
           
                
                
            }
            
          
            
