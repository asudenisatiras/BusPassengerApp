//
//  BorderExtension.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 7.04.2023.
//


import UIKit


extension UIView {

   @IBInspectable var cornerRadius: CGFloat{
       get{return self.cornerRadius}
       set{
            self.layer.cornerRadius = newValue
        }
    }
}
