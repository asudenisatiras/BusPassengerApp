//
//  noregistViewController.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 4.04.2023.
//

import UIKit

class noregistViewController: UIViewController {
    
    let data3 = ["Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin", "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa", "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan", "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta", "Mersin", "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir", "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa", "Kahramanmaraş", "Mardin", "Muğla", "Muş", "Nevşehir", "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas", "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Şanlıurfa", "Uşak", "Van", "Yozgat", "Zonguldak", "Aksaray", "Bayburt", "Karaman", "Kırıkkale", "Batman", "Şırnak", "Bartın", "Ardahan", "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye", "Düzce"]
    
    
    @IBOutlet weak var fromTextField: UITextField!
    
    
    @IBOutlet weak var toCityTextField: UITextField!
    
    
    @IBOutlet weak var datesPicker: UIDatePicker!

    
    
    var pickerView: UIPickerView?
    let dateFormatter = DateFormatter()
    var date: String = ""
    var tomorrow: Bool = false
    var today: Bool = true
    var travelDate: String!
    

    override func viewDidLoad() {
        super.viewDidLoad()
    
        let tapDetection = UITapGestureRecognizer(target: self, action: #selector(self.tapDetectionMethod))
                view.addGestureRecognizer(tapDetection)
        
        pickerView = UIPickerView()
        pickerView?.delegate = self
        pickerView?.dataSource = self
        
        toCityTextField.inputView = pickerView
        fromTextField.inputView = pickerView
        
        
        self.navigationItem.hidesBackButton = true
        dateFormatter.dateFormat = "dd/MM/yyyy"
        date = dateFormatter.string(from: datesPicker.date)
        
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 44))
            let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
            toolbar.setItems([UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), doneButton], animated: true)
            toCityTextField.inputAccessoryView = toolbar
            fromTextField.inputAccessoryView = toolbar
            
    }
     @objc func doneButtonTapped() {
        view.endEditing(true)
    }
    
    @objc func tapDetectionMethod() {

            view.endEditing(true)
        }
    
    @IBAction func todaysDate(_ sender: Any) {
        
        tomorrow = false
            
            if !today {
                let modifyDate = Calendar.current.date(byAdding: .day, value: -1, to: datesPicker.date)
                date = dateFormatter.string(from: modifyDate ?? datesPicker.date)
                datesPicker.date = modifyDate ?? datesPicker.date
                today = true
            }
       }
    
    @IBAction func tomorrowsDate(_ sender: Any) {
        today = false
        
        if !tomorrow {
            let modifyDate = Calendar.current.date(byAdding: .day, value: 1, to: datesPicker.date)
            date = dateFormatter.string(from: modifyDate ?? datesPicker.date)
            datesPicker.date = modifyDate ?? datesPicker.date
            tomorrow = true
        }
        
        
    }
    
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       if segue.identifier == "BusCompany" {
            if let destinationViewController = segue.destination as? CompanyViewController {
                destinationViewController.toCityName = (toCityTextField.text ?? "Error")
                destinationViewController.fromCityName = (fromTextField.text ?? "Error")
                //UserDefaults.standard.set(String(datesPicker.date)!), forKey: "Date" )
                destinationViewController.date = date
            }
        }
    }
    
    @IBAction func findTicketbutton(_ sender: UIButton) {
        if fromTextField.text == "" {
         
                Alert.showAlert(alertTitle: "Warning!", alertMessage: "No City Selection", defaultTitle: "OK", viewController:self)
            
            }
        if toCityTextField.text ==  "" {
            Alert.showAlert(alertTitle: "Warning!", alertMessage: "No City Selection", defaultTitle: "OK", viewController:self)
            
        }
        

       let findDate = datesPicker.calendar.dateComponents([.day, .month, .year], from: datesPicker.date)
        travelDate = "\(findDate.day!)" + "/" + "\(findDate.month!)" + "/" + "\(findDate.year!)"
        UserDefaults.standard.set(travelDate, forKey: "traveldate")
        }
    
    @IBAction func actionDatePicker(_ sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
               dateFormatter.dateFormat = "dd/MM-yyyy"
               date = dateFormatter.string(from: datesPicker.date)
        print(date)
        
        
        }
        
    }
    

extension noregistViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return data3.count
    }

    func pickerView(_  pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return data3[row]
        }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {

        if fromTextField.isFirstResponder {
                    fromTextField.text = data3[row]
                    UserDefaults.standard.set(data3[row], forKey: "fromCity")
                } else if toCityTextField.isFirstResponder {
                    toCityTextField.text = data3[row]
                    UserDefaults.standard.set(data3[row], forKey: "toCity")
                }
    }

}

