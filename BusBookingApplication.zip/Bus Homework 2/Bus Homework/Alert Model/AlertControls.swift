//
//  AlertControls.swift
//  Bus Homework
//
//  Created by Asude Nisa Tıraş on 10.04.2023.
//

import Foundation
import UIKit

class Alert {
 
    static func showAlert(alertTitle: String,
                          alertMessage: String,
                          defaultTitle: String,
                          viewController: UIViewController) {


        let alert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)

        let defaultButton = UIAlertAction(title: defaultTitle, style: .default)
       

        alert.addAction(defaultButton)
       

        viewController.present(alert, animated: true,completion: nil)

    }



}


